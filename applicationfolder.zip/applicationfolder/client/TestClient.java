// remember to use Manager createAndAdd, not CentralList
// Rememebr formatted names when using input to create stuff.

// make "Do you want to replace the old recipe/ingredient with a new one?"
// Remove methods
// in managers

// Opprett en klasse som på sikt skal bli brukergrensesnittet og dermed ta seg
// av all
// brukerinteraksjon. Opprett to metoder; start() og init().
