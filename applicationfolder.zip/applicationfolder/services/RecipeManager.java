package applicationfolder.services;

import applicationfolder.models.Recipe;
import applicationfolder.models.CentralRecipeList;

/**
 * Class to manage and check specific things related to the Recipe and
 * CentralRecipeList classes.
 */
public class RecipeManager {
  private final Recipe recipe;
  private final CentralRecipeList centralRecipeList;

  public RecipeManager(Recipe recipe, CentralRecipeList centralRecipeList) {
    this.recipe = recipe;
    this.centralRecipeList = centralRecipeList;
  }

  // Adds specific ingredient to specific recipe
}
// Outer hashmap: Recipe as key, another hashmap as value
// - I.e. HashMap called "Lasagna"
// Inner hashmap: Ingredient as key, amount as value.
// - Multiple ingredients to make the lasagna

// Create new recipe from ingredients (Method for it, done in client)
// Remove ingredient from recipe
// Delete recipe

// Total weight of recipe
// Total price of recipe
// Enough ingredients for recipe
// - If missing, what is missing?
// - If enough, is something expired?
