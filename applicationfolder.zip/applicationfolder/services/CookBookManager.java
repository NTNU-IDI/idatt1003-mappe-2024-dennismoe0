package applicationfolder.services;

public class CookBookManager {

}

// Outer hashmap with key CookBook and value hashmap
// Inner hashmap with